package cat.institutmvm;

import java.io.FileWriter;
import java.util.Scanner;
import java.io.IOException;
import java.io.BufferedWriter;

public class Main {

    private static final String MSG_1 = "Introdueix el codi: ";
    private static final String MSG_2 = "Introdueix el nom del projecte: ";
    private static final String MSG_3 = "Introdueix la descripció: ";
    private static final String MSG_4 = "Introdueix el codi client: ";
    private static final String MSG_5 = "Introdueix l'import: ";
    private static final String MSG_6 = "Introdueix la data inici (dd/MM/yyyy): ";
    private static final String MSG_7 = "Introdueix la data fi (dd/MM/yyyy): ";
    private static final String MSG_8 = "|";
    private static final String MSG_9 = "Dades guardades al fitxer";
    private static final String MSG_10 = "Error al escriure les dades al fitxer.";
 

    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);

        System.out.print(MSG_1);
        String codi = sc.nextLine();

        System.out.print(MSG_2);
        String nom_proj = sc.nextLine();

        System.out.print(MSG_3);
        String desc = sc.nextLine();

        System.out.print(MSG_4);
        String codiC = sc.nextLine();

        System.out.print(MSG_5);
        String importC = sc.nextLine();

        System.out.print(MSG_6);
        String dataI = sc.nextLine();

        System.out.print(MSG_7);
        String dataFi = sc.nextLine();

        try ( FileWriter fw = new FileWriter("files/prueba.txt")) {
            BufferedWriter bw = new BufferedWriter(fw);
            fw.write("codi " + MSG_8 + "nomProjecte" + MSG_8 + "descripció" + MSG_8 + "codiClient" + MSG_8 + "importCompra" + MSG_8 + "dataInici" + MSG_8 + "dataFi" + MSG_8 +  "\n");
            bw.write(codi + "\t" + MSG_8 + nom_proj + MSG_8 + desc + "\t" + MSG_8 + codiC + "\t" + MSG_8 + importC + "\t" + MSG_8 + dataI + "\t" + MSG_8 + dataFi + "\t" + "\n");
            bw.close();
           
            System.out.println(MSG_9);

        } catch (IOException e) {
            System.out.println(MSG_10);
        }
    }
}
